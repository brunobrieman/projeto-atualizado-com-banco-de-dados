
	

<?php
 include 'cabecalho.php';
 include 'funcoes.php';
?>


	 
	<div class=page>

   
     
       <br>
       <br>
        <center>
         <h1 class="animated fadeInLeftBig tituloIndex"> BWP Resenhas Esportivas</h1>
               	<br>
               	<br>
               	<h1 class="animated fadeInRightBig subtituloIndex">Resenhas esportivas da melhor qualidade</h1>
               <h1 class="animated fadeInLeftBig subtitulo2Index">entre para uma melhor experiencia</h1>
             	<br>
              <?php include 'parte.html'; ?>
                <button class="animated fadeInUp" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Entrar</button>
                <a href="cadastro.php"><button class="animated fadeInUp "style="width:auto">Cadastre-se</button></a>
                <link href="css/bootstrap.min.css" rel="stylesheet">

               	
	
               	


     
     	<section class="animated shake colunaSeta">
     	<a href="#tituloNew"><img class="seta" src="imagens/seta.jpg"></a>
     	   </center>
     	</section>
   </div>
<div>
  
     <style>
    .dropbtn {
      background: white
      color: black;
      padding: 16px;
      font-size: 16px;
      border: none;
      margin-left: 300%;
     
          }

    .dropdown {
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 1;
      margin-left: 300%;
      margin-top: -3%;
      width: 100%;
     
      
    }

    .dropdown-content a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover {background-color: #ddd;}

    .dropdown:hover .dropdown-content {display: block;}

    .dropdown:hover .dropbtn {background-color: grey;}
  </style>
 <br>

  <div class="dropdown">
        <button class="dropbtn">Resenhas Recentes</button>
        <div class="dropdown-content">
          <a href="todasResenhas.php">Todas as Resenhas</a>
          <a href="classificacao_Resenhas.php">Maior Classificaçao</a>
        
        </div>
  </div>
    <br>
  <br>          
      
<?php

 $lista=listaResenhas();
 $cont = 0;
 
  foreach ($lista as $dados) {
    $cont++;
    if ($cont>3) {
        break;
    }else{

   



echo '

  
<div class="responsive">
  <div class="gallery">
     <a href="detalha_resenha.php?cod='.$dados["cod_jogo"].'">
      <img src="imagens/'.$dados['foto'].'" alt="Trolltunga Norway" width="300" height="200">
       
    </a>
    <div class="desc">'.$dados['Nome'].'</div>
  </div>
</div>
';

}
}
?>
	


</body>
</html>

