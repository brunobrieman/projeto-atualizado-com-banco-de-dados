<?php
include'cabecalho.php'
?>
<body>
	<br>
	<br>
	<br>
	<br><br>
	<style type="text/css">
		.coluna1s{
			
			width: 40%;
			height: 50%;
			margin-left: 5%;
			float: left;
				}

		.label1s{
			margin-left: 10%;
			font-size: 20px;
		}
		.input1s{
			margin-left: 10%;
			width: 80%;
		}
		.categoria_SHOW{
			height: 40px;
			width: 100%;
		}
		.input3{

			width: 100%;
		}
		.showsao{
			width: 100%;
			height: 40px;
		}
		.coluna2s{
			width: 49%;
			float: left;
		
		}
		.input2s{
			margin-left: 15%;
			width: 80%;
		}
		.label2s{
			margin-left: 15%;
			font-size: 20px; 
		}
	</style>

	<form>
		
	<div>
		<center><h1 class="tituloCadastro2">Cadastre uma resenha Esportiva</h1></center>
	</div>
	<br>
		<section class="coluna1s">
			<label class="label1s">Nome do Jogo:</label><br>
			<input class="input1s" type="text" name="name" placeholder="titulo do jogo"><br>

			<label class="label1s">Categorias:</label><br>
			
			<select class="categoria_SHOW">
				<option value="">Categorias:</option>
				<option value="1">Futebol</option>
				<option value="2">Basquete</option>
				<option value="3">Automotivo</option>
				<option value="4">Basebol</option>
				<option value="5">Tênis</option>
				<option value="6">Luta</option>
				<option value="7">Futebol Americano</option>
				<option value="8">Hockey</option>
				<option value="9">Skate</option>
				<option value="10">Luta</option>
			</select><br>
			
		 <label class="label1s">Sinopsia</label><br>
			<textarea class="input3" name="comentário" rows="2" cols="40" placeholder="vai aparecer na home"></textarea><br>

			
			<label class="label1s">Insira a URL do site do desenvolvedor:</label><br><input class="showsao" type="url" name="homepage">


		</section>

		<section class="coluna2s">
			<label class="label2s">Resenha:</label> <br>
			<textarea class="input2s" name="comentário" rows="15" cols="40"></textarea>
		</section>	
	</form>

	

			<SECTION>
				<a href="usuario.php"><button class="buttonCadastro">Cadastrar</button></a>
			</SECTION>
		</form>
	</section>

 -->