<?php
	include 'cabecalho.php';
	include 'functions.php';

	$codigo = $_GET['cod'];
	$jogo = buscaJogo($codigo);
	$requisitos_minimos = buscaRequisitosMinimos($codigo);
	$requisitos_recomendados = buscaRequisitosRecomendados($codigo);
?>
	<br>
	<br>
	<br>
	<center><h2 class="ui horizontal divider header"><?= $jogo['nome_jogo']?></h2></center>
	<br>

	<p class="texto_resenha"><?= $jogo['resenha']?></p>

	<center><img class="img2" src="imagem/<?= $jogo['imagem_resenha']?>"></center>
	<br>

		<p class="texto_resenha">Requisitos Minímos:</p>
			<ul>
				<li class="texto_resenha"><p>Sistema Operacional:<?= $requisitos_minimos['os'] ?></p></li>
				<li class="texto_resenha"><p>CPU: <?= $requisitos_minimos['cpu'] ?></p></li>
				<li class="texto_resenha"><p>RAM: <?= $requisitos_minimos['ram'] ?></p></li>
				<li class="texto_resenha"><p>Placa de Vídeo: <?= $requisitos_minimos['video'] ?></p></li>
				<li class="texto_resenha"><p>Armazenamento: <?= $requisitos_minimos['hdd']?></p></li>
				<?php
					if($requisitos_minimos['directx'] !=0){
						print ('<li class= "texto_resenha"><p>DirectX:'.$requisitos_minimos['directx'].'</p></li>');
					}
				?>
			</ul>
	<br>
		<p class="texto_resenha">Requisitos Recomendados: </p>
			<ul>
				<li class="texto_resenha"><p>Sistema Operacional:<?= $requisitos_recomendados['os'] ?></p></li>
				<li class="texto_resenha"><p>CPU: <?= $requisitos_recomendados['cpu'] ?></p></li>
				<li class="texto_resenha"><p>RAM: <?= $requisitos_recomendados['ram'] ?></p></li>
				<li class="texto_resenha"><p>Placa de Vídeo: <?= $requisitos_recomendados['video'] ?></p></li>
				<li class="texto_resenha"><p>Armazenamento: <?= $requisitos_recomendados['hdd']?></p></li>
				<?php
					if($requisitos_recomendados['directx'] !=0){
						print ('<li class= "texto_resenha"><p>DirectX:'.$requisitos_recomendados['directx'].'</p></li>');
					}
				?>
			</ul>
	<br>
	<div class="excluir">	
		<a href="confirmar_exclusao.php">
			<button class="ui red button para_lado confirmar_exclusao">
				<i class="trash alternate outline icon"></i>
					Excluir
			</button>
		</a>
		<a href="editar.php">	
			<button class="ui blue button para_lado">
				<i class="pencil alternate icon"></i>
				Editar
			</button>
		</a>
	</div>

	<br>
	<br>

	<div class="texto_resenha">
		<a href="denuncia_resenha.php">
			<h5>Deseja denunciar essa resenha?</h5>
		</a>
		<br>
			<center><h4>Avalie esta resenha: </h4><div class="ui star rating" data-rating="3" data-max-rating="5"></div></center>
	</div>


	<br>
		
	<br>

	<br>
	<br>
	<center><h2 class="ui horizontal divider header">Comentários</h2></center>
	<br>
	<br>


	<div class="texto_resenha">
		<div class="ui comments">
		  <div class="comment">
		    <a class="avata" id="ajustar">
		      <img src="imagem/steve.jpg">
		    </a>
		    <div class="content">
		      <a class="author">Steve Jobes</a>
		      <div class="metadata">
		        <div class="date">2 dias atrás</div>
		      </div>
		      <div class="text">
		        Revolutionary!
		      </div>
		      <div class="actions">
		        	<a class="reply active red">Denunciar</a>
		      </div>
		      <div class="comment">
			    <a class="avata" id="ajustar">
			      <img src="imagem/tom.jpg">
			    </a>
			    <div class="content">
			      <a class="author">Você</a>
			      <div class="metadata">
			        <div class="date">2 segundos atrás</div>
			      </div>
			      <div class="text">
			        Impressionante!
			      </div>
		    	</div>
		    	<div class="actions">
		        	<a class="reply active">Alterar</a>
		        	<a class="reply active" font-color:red;>Excluir</a>
		        </div>
		  </div>
		  <br>
		      <form class="ui reply form">
		        <div class="field">
		          <textarea></textarea>
		        </div> 
		        <div class="ui primary submit labeled icon button">
		          <i class="icon edit"></i> Publique seu comentário
		        </div>
		      </form>
		    </div>
		  </div>
		</div>
	</div>
	<?php
	include 'rodape.php';
	?>