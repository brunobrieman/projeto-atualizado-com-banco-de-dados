<html>
<head>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/core.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<script type="text/javascript" src="js.js"></script>
	<link rel="stylesheet" type="text/css" href="Semantic/semantic.css">
	<script type="text/javascript" src="Semantic/semantic.js"></script>
	<script type="text/javascript" src="Semantic/semantic.min.js"></script>
	<link rel="stylesheet" type="text/css" href="estilo.css">
	<link rel="shortcut icon" href="imagem/favicon.ico" />
	<title>HRF-Resenhas</title>
</head>
<nav>
    <div class="ui inverted menu fixed">
    <div class="ui stackable">
		<a href="index.php"><div class="item">
			<img src="imagem/logo.png">
		</div></a>
	</div>
    <a class="item" href="index.php">Home</a>
    <a class="item" href="minhas_resenhas.php">Minhas Resenhas</a>
    <a class="item">Fórum</a>
    <a class="item" href="ranking.php">Ranking</a>
    <div class="right menu">
	    <div class="ui category search mini para_centralizar">
	 		 <div class="ui icon input">
	    		<input class="prompt" type="text" placeholder="Pesquisar">
	    		<i class="search icon"></i>
	  		</div>
	  		<div class="results"></div>
		</div>
        <a class="ui item" href="login.php">Login</a>
    </div>
    </div>
</nav>
<br>