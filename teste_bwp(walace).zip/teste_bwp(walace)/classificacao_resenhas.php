<?php

include 'cabecalho.php';
?>

<body>
	<style type="text/css">
		.titulo_resenha_classifi{
			margin-left: 30%;
		}
		.primeiro_section{
			width: 20%;
			height: 30%;
			margin-left: 5%;
			float: left;
		}
		.primeiro_lugar{
			margin-left: 5%;
			color:white;
		}
		.segundo_lugar{
			margin-left: 30%;
			color:white;

		}
		.segundo_section{
			width: 20%;
			height: 30%;
			margin-left: 5%;
			float: left;
			margin-top: -1.5%;
		}
		.terceiro_lugar{
			margin-left: 55%;
			color:white;

		}
		.terceiro_section{
			width: 20%;
			height: 30%;
			margin-left: 5%;
			float: left;
			margin-top: -3%;
		}
		.conteudotudoo{
			margin-left: 10%;
		}
		.primeiro_classifi{
			margin-left: 100%;

		}
	</style>
	<div>
		<br>
		<br>
		<h1 class="titulo_resenha_classifi">Ranking das resenhas mais bem avaliadas!</h1>
	</div>
<div class="conteudotudoo">	

<div class="primeiro_lugar">1ºlugar</div>	
<section class="primeiro_section">
	<div id="Contact" class="tabcontent">

<div class="novas_reasenhas_usuario">
  <link rel="stylesheet" type="text/css" href="Semantic/semantic.css">
	  <script type="text/javascript" href="Semantic/semantic.js"></script>
<div class="ui card">
  <div class="content">
    <div class="right floated meta">1ºlugar</div>
    <img class="ui avatar image icone_direita" src="imagens/pessoa.jpg"> 
    <p class="icones icone_direita">fifa</p> 
  </div>
  <div class="image">
    <img src="imagens/fifa10.jpg">

  </div>
  <div class="content">
    <span class="right floated">
      <i class="heart outline like icon icones"></i>
      <p class="icones icone_direita">67 likes</p>
    </span>
    <i class="comment icon icones icone_direita"></i>
    <p class="icones icone_direita"> 7 comments </p>
  </div>
  
  </div>
</div>
</div>


</section>
<div class="segundo_lugar">2ºlugar</div>	
<section class="segundo_section">
	<div id="Contact" class="tabcontent">

<div class="novas_reasenhas_usuario">
  <link rel="stylesheet" type="text/css" href="Semantic/semantic.css">
	  <script type="text/javascript" href="Semantic/semantic.js"></script>
<div class="ui card">
  <div class="content">
    <div class="right floated meta">2ºlugar</div>
    <img class="ui avatar image icone_direita" src="imagens/pessoa.jpg"> 
    <p class="icones icone_direita">PES</p> 
  </div>
  <div class="image">
    <img src="imagens/pes.jpg">

  </div>
  <div class="content">
    <span class="right floated">
      <i class="heart outline like icon icones"></i>
      <p class="icones icone_direita">48 likes</p>
    </span>
    <i class="comment icon icones icone_direita"></i>
    <p class="icones icone_direita"> 4 comments </p>
  </div>
  
  </div>
</div>
</div>
</section>

</section>
<div class="terceiro_lugar">3ºlugar</div>	
<section class="terceiro_section">
	<div id="Contact" class="tabcontent">

<div class="novas_reasenhas_usuario">
  <link rel="stylesheet" type="text/css" href="Semantic/semantic.css">
	  <script type="text/javascript" href="Semantic/semantic.js"></script>
<div class="ui card">
  <div class="content">
    <div class="right floated meta">3ºlugar</div>
    <img class="ui avatar image icone_direita" src="imagens/pessoa.jpg"> 
    <p class="icones icone_direita">NBA</p> 
  </div>
  <div class="image">
    <img src="imagens/live.jpg">

  </div>
  <div class="content">
    <span class="right floated">
      <i class="heart outline like icon icones"></i>
      <p class="icones icone_direita">26 likes</p>
    </span>
    <i class="comment icon icones icone_direita"></i>
    <p class="icones icone_direita"> 3 comments </p>
  </div>
  
  </div>
</div>
</div>
</section>


</div>

<div>
	<h1 class="primeiro_classifi">1º lugar</h1>
</div>
<div>
	<h1 class="primeiro_classifi">2º lugar</h1>
</div>
<div>
	<h1 class="primeiro_classifi">3º lugar</h1>
</div>
















</body>