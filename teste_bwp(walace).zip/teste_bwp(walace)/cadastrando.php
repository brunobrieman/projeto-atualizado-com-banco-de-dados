<!DOCTYPE html>
<html>
<head>

</head>
<body>



<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "usuario";
$link = mysqli_connect($host, $user, $pass, $banco);
//mysqli_connect("127.0.0.1", "my_user", "my_password", "my_db");

if (!$link) {
    die('Erro ao conectar ao banco: ' . mysql_error());
}
echo 'Cadastrado';

?>


<?php


$nome = $_POST['nome'];
$email = $_POST['email'];
$apelido= $_POST['apelido'];
$senha = $_POST['senha'];
$confirmar = $_POST['confirmarSenha'];
$data=$_POST['dataNascimento'];

$envia_banco="INSERT INTO usuario(nome,email,apelido,senha,confirmarSenha,data) VALUES ('".$nome."', '".$email."','".$apelido."','".$senha."','".$confirmar."','".$data."')";

if (mysqli_query($link, $envia_banco)) {
      echo "";
} else {
      echo "Error: " . $envia_banco . "<br>" . mysqli_error($link);
} 





?>
</body>
</html>
